package com.virtusa.visa.VisaProcessing.service;

import com.virtusa.visa.VisaProcessing.model.Visa;
import com.virtusa.visa.VisaProcessing.model.VisaShow;
import com.virtusa.visa.VisaProcessing.repository.UserRepository;
import com.virtusa.visa.VisaProcessing.repository.VisaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class VisaImpl implements VisaSystem {

   @Autowired
   UserRepository userRepository;

   @Autowired
    VisaRepository visaRepository;

    @Override
    public void addVisaDetails( Visa userVisa){
       visaRepository.save(userVisa);
    }

    @Override
    public List<Visa> getAllPendingRequest(){
        List<Visa> pendingVisa;
        pendingVisa = visaRepository.findPendingVisas();
        return pendingVisa;
    }

    private List<Visa> checkStatus(String username){
        List<Visa> statusList;
        statusList = visaRepository.userVisas(username);
        return statusList;
    }

    private static String getDateTime(long timestamp){
        String dateTimeFormat = "dd-MMM-yyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateTimeFormat);
        return simpleDateFormat.format(new Date(timestamp));
    }

    @Override
    public List<VisaShow> showVisaStatus(String username){
        List<VisaShow> visaShows = new ArrayList<>();
        List<Visa> visaStatus;
        visaStatus = checkStatus(username);
        for (Visa status : visaStatus) {
            String dateIssue;
            String expireDate;
            if (status.getDateIssue() == null){
                dateIssue = "--"; expireDate = "--";
            } else {
                dateIssue = getDateTime(status.getDateIssue());
             expireDate =getDateTime(status.getDateIssue() + TimeUnit.DAYS.toMillis(status.getValidity()));
            }
            VisaShow visa = new VisaShow(status.getVisaId(), status.getUserName(), status.getProject(),
                    status.getStatus(), status.getDestination(),status.getReason(),dateIssue,expireDate);
            visaShows.add(visa);
        }
        return visaShows;
    }

    @Override @Transactional
    public void updateStatus(Integer visaId){
        Long epoch = Instant.now().toEpochMilli();
        visaRepository.alterStatus(visaId);
        visaRepository.alterTime(visaId,epoch);
    }
}
