package com.virtusa.visa.VisaProcessing.service;

import com.virtusa.visa.VisaProcessing.model.UserModel;
import com.virtusa.visa.VisaProcessing.model.Visa;
import com.virtusa.visa.VisaProcessing.model.VisaShow;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface VisaSystem {

    void addVisaDetails(Visa userVisa);

    List<Visa> getAllPendingRequest();

    List<VisaShow> showVisaStatus(String username);

    void updateStatus(Integer visaId);
}
