package com.virtusa.visa.VisaProcessing.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter @Setter @AllArgsConstructor @NoArgsConstructor @Entity(name = "visa") @Table(name = "VisaManagement")
public class Visa {
    @Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer visaId;
    private String userName;
    private String project;
    private String status;
    private String destination;
    private Long validity;
    private String reason;
    private Long dateIssue;
}
