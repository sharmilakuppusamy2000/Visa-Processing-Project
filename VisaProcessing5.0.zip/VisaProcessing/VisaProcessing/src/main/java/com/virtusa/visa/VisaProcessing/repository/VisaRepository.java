package com.virtusa.visa.VisaProcessing.repository;

import com.virtusa.visa.VisaProcessing.model.Visa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VisaRepository extends JpaRepository<Visa, String> {

    Visa findByUserName(String userName);

    @Query(value = "SELECT * FROM visa_management WHERE status = 'Pending'", nativeQuery = true)
    List<Visa> findPendingVisas();

    @Query(value = "SELECT * FROM visa_management WHERE user_name = :username", nativeQuery = true)
    List<Visa> userVisas(@Param("username") String userName);

    @Modifying
    @Query(value = "UPDATE visa_management SET status = 'Approved' WHERE visa_id = :id", nativeQuery = true)
    void alterStatus(@Param("id") Integer visaId);

    @Modifying
    @Query(value = "UPDATE visa_management SET date_issue = :time WHERE visa_id = :id", nativeQuery = true)
    void alterTime(@Param("id") Integer visaId, @Param("time") Long epoch);
}
