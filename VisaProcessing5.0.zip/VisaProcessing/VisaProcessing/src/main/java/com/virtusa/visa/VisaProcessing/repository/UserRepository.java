package com.virtusa.visa.VisaProcessing.repository;

import com.virtusa.visa.VisaProcessing.model.UserModel;
import com.virtusa.visa.VisaProcessing.model.Visa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UserRepository extends JpaRepository<UserModel , String> {

    UserModel findByUserName(String userName);

    @Query(value = "SELECT * FROM user WHERE user_type = 'employee'", nativeQuery = true)
    List<UserModel> allEmployeeList();

    @Query(value = "SELECT * FROM user WHERE user_type = 'admin'", nativeQuery = true)
    List<UserModel> allExecutiveList();
}
