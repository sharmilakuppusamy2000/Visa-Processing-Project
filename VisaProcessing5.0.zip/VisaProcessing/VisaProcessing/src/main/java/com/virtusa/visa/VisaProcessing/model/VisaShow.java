package com.virtusa.visa.VisaProcessing.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class VisaShow {
    private Integer visaId;
    private String userName;
    private String project;
    private String status;
    private String destination;
    private String reason;
    private String dateIssue;
    private String endDate;
}
