package com.virtusa.visa.VisaProcessing.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class RegisterDao {
    private String userName;
    private String fullName ;
    private String userEmail;
    private Long mobNo;
    private String password;
    private String userType;
    private Long passportNo;
}
